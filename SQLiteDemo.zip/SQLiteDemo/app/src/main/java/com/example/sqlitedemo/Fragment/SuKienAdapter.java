package com.example.sqlitedemo.Fragment;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.sqlitedemo.Models.SuKien;
import com.example.sqlitedemo.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.firebase.ui.storage.images.FirebaseImageLoader;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class SuKienAdapter extends FirebaseRecyclerAdapter<SuKien,SuKienAdapter.Holder> {

    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageRef = storage.getReference();

    public SuKienAdapter(@NonNull FirebaseRecyclerOptions<SuKien> options) {
        super(options);
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_sukien,parent,false);
        return new SuKienAdapter.Holder(v);
    }

    @Override
    protected void onBindViewHolder(@NonNull Holder holder, int position, @NonNull SuKien model) {
        holder.ten.setText(model.getTenSK());
        //holder.stt.setText(model.getStt());
        holder.ngay.setText(model.getNgayDang());
        //holder.nd.setText(model.getNoiDung());
        Glide.with(holder.image.getContext()).load(model.getLink()).into(holder.image);
    }

    public class Holder extends RecyclerView.ViewHolder {
        TextView stt, ten, ngay, nd;
        ImageView image;
        public Holder(@NonNull View itemView) {
            super(itemView);
            //stt = (TextView) itemView.findViewById(R.id.list_stt);
            ten = (TextView) itemView.findViewById(R.id.list_tensk);
            //nd = (TextView) itemView.findViewById(R.id.list_noidungsk);
            ngay = (TextView) itemView.findViewById(R.id.list_ngaydang);
            image = (ImageView) itemView.findViewById(R.id.image_sukien);
        }
    }
}
