package com.example.sqlitedemo.Models;

public class Account {

    public String IdLogin;
    public String Pass;

    public Account() {
    }

    public Account(String idLogin, String pass) {
        IdLogin = idLogin;
        Pass = pass;

    }
}
