package com.example.sqlitedemo.Models;

public class PhanQuyen {
}
