package com.example.sqlitedemo.Models;

public class Admin {
    public String ID;
    public String HoTenAD;
    public String GioiTinh;
    public String NgaySinh;
    public String DiaChi;
    public String SDT;

    public Admin() {
    }

    public Admin(String id, String hoTenAD, String gioiTinh, String ngaySinh, String diaChi, String SDT) {
        ID = id;
        HoTenAD = hoTenAD;
        GioiTinh = gioiTinh;
        NgaySinh = ngaySinh;
        DiaChi = diaChi;
        this.SDT = SDT;
    }
}
