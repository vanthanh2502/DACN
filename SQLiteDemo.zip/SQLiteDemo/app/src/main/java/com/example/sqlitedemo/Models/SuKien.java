package com.example.sqlitedemo.Models;

public class SuKien {
    String DanhMuc, Stt, TenSK, NgayDang, NoiDung, link;

    public SuKien() {
    }

    public SuKien(String danhmuc, String stt, String tenSK, String ngayDang, String noiDung, String link) {
        DanhMuc = danhmuc;
        Stt = stt;
        TenSK = tenSK;
        NgayDang = ngayDang;
        NoiDung = noiDung;
        this.link = link;
    }


    public String getTenSK() {
        return TenSK;
    }

    public void setTenSK(String tenSK) {
        TenSK = tenSK;
    }

    public String getNgayDang() {
        return NgayDang;
    }

    public void setNgayDang(String ngayDang) {
        NgayDang = ngayDang;
    }

    public String getNoiDung() {
        return NoiDung;
    }

    public void setNoiDung(String noiDung) {
        NoiDung = noiDung;
    }

    public String getDanhmuc() {
        return DanhMuc;
    }

    public void setDanhmuc(String danhmuc) {
        DanhMuc = danhmuc;
    }

    public String getStt() {
        return Stt;
    }

    public void setStt(String stt) {
        Stt = stt;
    }

    public String getDanhMuc() {
        return DanhMuc;
    }

    public void setDanhMuc(String danhMuc) {
        DanhMuc = danhMuc;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
