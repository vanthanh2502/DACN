package com.example.sqlitedemo.Models;

public class HocSinh {

    public String MaHS;
    public String HoTenHS;
    public String GioiTinh;
    public String NgaySinh;
    public String DiaChi;
    public String SDT;
    public String SDTPH;

    public HocSinh() {
    }

    public HocSinh(String maHS, String hoTenHS, String gioiTinh, String ngaySinh, String diaChi, String SDT, String SDTPH) {
        MaHS = maHS;
        HoTenHS = hoTenHS;
        GioiTinh = gioiTinh;
        NgaySinh = ngaySinh;
        DiaChi = diaChi;
        this.SDT = SDT;
        this.SDTPH = SDTPH;
    }
}

