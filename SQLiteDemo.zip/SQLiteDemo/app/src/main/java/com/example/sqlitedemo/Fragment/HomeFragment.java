package com.example.sqlitedemo.Fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.sqlitedemo.Models.SuKien;
import com.example.sqlitedemo.R;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.firebase.ui.database.SnapshotParser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.StorageReference;

import io.grpc.Context;

public class HomeFragment extends Fragment {
    View view;
    RecyclerView mRecyclerView;
    DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
    SuKienAdapter adapter;
    public static int STT = 1;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_home, container, false);

        mRecyclerView = (RecyclerView) view.findViewById(R.id.re_sk);
        LinearLayoutManager layoutManager = new LinearLayoutManager(view.getContext());
        mRecyclerView.setLayoutManager(layoutManager);

        DatabaseReference reference = ref.child("SuKien").child("TinBGD");
        FirebaseRecyclerOptions<SuKien> options = new FirebaseRecyclerOptions.Builder<SuKien>()
                .setQuery(reference, new SnapshotParser<SuKien>() {
                    @NonNull
                    @Override
                    public SuKien parseSnapshot(@NonNull DataSnapshot snapshot) {
                        return new SuKien(snapshot.child("DanhMuc").getValue().toString(),
                                snapshot.child("Stt").getValue().toString(),
                                snapshot.child("TenSK").getValue().toString(),
                                snapshot.child("NgayDang").getValue().toString(),
                                snapshot.child("NoiDung").getValue().toString(),
                                snapshot.child("link").getValue().toString());
                    }
                }).build();

        adapter = new SuKienAdapter(options);
        mRecyclerView.setAdapter(adapter);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}