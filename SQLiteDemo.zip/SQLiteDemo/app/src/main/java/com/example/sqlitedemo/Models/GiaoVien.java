package com.example.sqlitedemo.Models;

public class GiaoVien {
    public String MaGV;
    public String HoTenGV;
    public String GioiTinh;
    public String NgaySinh;
    public String DiaChi;
    public String SDT;

    public GiaoVien() {
    }

    public GiaoVien(String maGV, String  hoTenGV, String gioiTinh, String ngaySinh, String diaChi, String SDT) {
        MaGV = maGV;
        HoTenGV = hoTenGV;
        GioiTinh = gioiTinh;
        NgaySinh = ngaySinh;
        DiaChi = diaChi;
        this.SDT = SDT;
    }
}
